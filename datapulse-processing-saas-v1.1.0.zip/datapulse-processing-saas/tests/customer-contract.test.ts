import request from "supertest";
import { describe, expect, it } from "vitest";
import { createApp } from "../src/app.js";

const app = createApp();

describe("runtime contract", () => {
  it("retorna o customer quando o upstream respeita o contrato", async () => {
    const response = await request(app).get("/api/customers/customer-123");

    expect(response.status).toBe(200);
    expect(response.body.email).toBe("ada@example.com");
    expect(response.body.plan).toBe("pro");
  });

  it("interrompe uma quebra de contrato antes de propagá-la", async () => {
    const response = await request(app).get(
      "/api/customers/customer-123?broken=true",
    );

    expect(response.status).toBe(502);
    expect(response.body.code).toBe("UPSTREAM_CONTRACT_VIOLATION");
    expect(response.body.issues.length).toBeGreaterThan(0);
  });
});
