import { setTimeout as sleep } from "node:timers/promises";
import { describe, expect, it } from "vitest";
import { ReportJobManager } from "../src/jobs/report-job-manager.js";

describe("CPU-bound worker", () => {
  it("processa o trabalho fora da thread principal", async () => {
    const manager = new ReportJobManager(1);
    const job = manager.enqueue(10_000);

    // A chamada retorna imediatamente em estado enfileirado.
    expect(job.status).toBe("queued");

    let current = manager.get(job.id);
    for (let attempt = 0; attempt < 100; attempt += 1) {
      if (current?.status === "completed") break;
      if (current?.status === "failed") {
        throw new Error(current.error ?? "Worker falhou");
      }
      await sleep(20);
      current = manager.get(job.id);
    }

    expect(current?.status).toBe("completed");
    expect(current?.result?.primeCount).toBe(1229);
  });
});
