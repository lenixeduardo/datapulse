import express from "express";
import customerRoutes from "./routes/customer.routes.js";
import reportRoutes from "./routes/report.routes.js";

export function createApp() {
  const app = express();

  app.disable("x-powered-by");
  app.use(express.json({ limit: "100kb" }));
  app.use(express.static("public"));

  app.get("/health", (_req, res) => {
    res.json({ status: "ok", eventLoop: "responsive" });
  });

  app.get("/api", (_req, res) => {
    res.json({
      project: "DataPulse — Processing SaaS",
      cases: {
        cpuBound: "POST /api/reports",
        runtimeContract: "GET /api/customers/:id?broken=true",
        docker: "Veja Dockerfile + .dockerignore",
      },
    });
  });

  app.use("/api/reports", reportRoutes);
  app.use("/api/customers", customerRoutes);

  app.use((_req, res) => {
    res.status(404).json({ code: "NOT_FOUND" });
  });

  app.use(
    (
      error: unknown,
      _req: express.Request,
      res: express.Response,
      _next: express.NextFunction,
    ) => {
      console.error(error);
      res.status(500).json({ code: "INTERNAL_ERROR" });
    },
  );

  return app;
}
