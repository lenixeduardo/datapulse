import { z } from "zod";

/**
 * O schema é a fonte da verdade em runtime.
 * O tipo TypeScript é inferido a partir dele, evitando duplicação.
 */
export const customerContract = z.object({
  id: z.string().min(1),
  name: z.string().min(2),
  email: z.string().email(),
  plan: z.enum(["free", "pro", "enterprise"]),
  createdAt: z.string().datetime(),
});

export type Customer = z.infer<typeof customerContract>;
