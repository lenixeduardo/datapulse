import { Router } from "express";
import { z } from "zod";
import { customerContract } from "../contracts/customer.contract.js";
import { fetchCustomerFromUpstream } from "../services/customer-upstream.service.js";

const router = Router();

const paramsSchema = z.object({
  id: z.string().min(1).max(100),
});

const querySchema = z.object({
  broken: z.enum(["true", "false"]).optional().default("false"),
});

router.get("/:id", async (req, res, next) => {
  try {
    const params = paramsSchema.safeParse(req.params);
    const query = querySchema.safeParse(req.query);

    if (!params.success || !query.success) {
      return res.status(400).json({
        code: "INVALID_REQUEST",
        issues: [
          ...(params.success ? [] : params.error.issues),
          ...(query.success ? [] : query.error.issues),
        ],
      });
    }

    const rawCustomer = await fetchCustomerFromUpstream(
      params.data.id,
      query.data.broken === "true",
    );

    const validated = customerContract.safeParse(rawCustomer);

    if (!validated.success) {
      // Em produção: log estruturado + métrica/alerta, sem vazar payload sensível.
      console.error("[contract-violation] upstream customer inválido", validated.error.issues);

      return res.status(502).json({
        code: "UPSTREAM_CONTRACT_VIOLATION",
        message: "A resposta do serviço upstream não respeita o contrato esperado.",
        issues: validated.error.issues.map((issue) => ({
          path: issue.path.join("."),
          message: issue.message,
        })),
      });
    }

    return res.json(validated.data);
  } catch (error) {
    next(error);
  }
});

export default router;
