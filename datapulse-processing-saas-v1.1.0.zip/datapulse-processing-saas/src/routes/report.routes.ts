import { Router } from "express";
import { z } from "zod";
import { reportJobs } from "../jobs/report-job-manager.js";

const router = Router();

const createReportSchema = z.object({
  title: z.string().trim().min(2).max(80).optional(),
  sourceFile: z.string().trim().min(1).max(120).optional(),
  limit: z.number().int().min(1_000).max(20_000_000).default(250_000),
});

const jobParamsSchema = z.object({
  id: z.string().uuid(),
});

router.get("/", (_req, res) => {
  const jobs = reportJobs.list();
  return res.json({
    jobs,
    summary: {
      total: jobs.length,
      processing: jobs.filter((job) => job.status === "processing").length,
      queued: jobs.filter((job) => job.status === "queued").length,
      completed: jobs.filter((job) => job.status === "completed").length,
      failed: jobs.filter((job) => job.status === "failed").length,
    },
  });
});

router.post("/", (req, res) => {
  const parsed = createReportSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({
      code: "INVALID_INPUT",
      issues: parsed.error.issues,
    });
  }

  const job = reportJobs.enqueue(parsed.data.limit, {
    title: parsed.data.title,
    sourceFile: parsed.data.sourceFile,
  });

  return res
    .status(202)
    .location(`/api/reports/${job.id}`)
    .json({
      ...job,
      statusUrl: `/api/reports/${job.id}`,
      message: "Processamento CPU-bound enviado para Worker Thread.",
    });
});

router.get("/:id", (req, res) => {
  const parsed = jobParamsSchema.safeParse(req.params);
  if (!parsed.success) {
    return res.status(400).json({ code: "INVALID_JOB_ID" });
  }

  const job = reportJobs.get(parsed.data.id);
  if (!job) {
    return res.status(404).json({ code: "JOB_NOT_FOUND" });
  }

  return res.json(job);
});

export default router;
