import { parentPort, workerData } from "node:worker_threads";

interface WorkerInput {
  limit: number;
}

function isPrime(value: number): boolean {
  if (value < 2) return false;
  if (value === 2) return true;
  if (value % 2 === 0) return false;

  const max = Math.floor(Math.sqrt(value));
  for (let divisor = 3; divisor <= max; divisor += 2) {
    if (value % divisor === 0) return false;
  }
  return true;
}

function countPrimes(limit: number): number {
  let count = 0;
  const progressStep = Math.max(1, Math.floor(limit / 100));

  for (let value = 2; value <= limit; value += 1) {
    if (isPrime(value)) count += 1;

    if (value % progressStep === 0) {
      parentPort?.postMessage({
        type: "progress",
        progress: Math.min(99, Math.round((value / limit) * 100)),
      });
    }
  }

  return count;
}

const { limit } = workerData as WorkerInput;
const startedAt = performance.now();
const primeCount = countPrimes(limit);
const durationMs = Math.round(performance.now() - startedAt);

parentPort?.postMessage({
  type: "completed",
  primeCount,
  durationMs,
});
