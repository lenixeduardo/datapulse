import { availableParallelism } from "node:os";
import { randomUUID } from "node:crypto";
import { Worker } from "node:worker_threads";

export type ReportJobStatus = "queued" | "processing" | "completed" | "failed";

export interface ReportJob {
  id: string;
  title: string;
  sourceFile: string;
  status: ReportJobStatus;
  progress: number;
  input: { limit: number };
  createdAt: string;
  updatedAt: string;
  result?: {
    primeCount: number;
    durationMs: number;
  };
  error?: string;
}

interface WorkerProgress {
  type: "progress";
  progress: number;
}

interface WorkerCompleted {
  type: "completed";
  primeCount: number;
  durationMs: number;
}

type WorkerMessage = WorkerProgress | WorkerCompleted;

export class ReportJobManager {
  private readonly jobs = new Map<string, ReportJob>();
  private readonly pending: string[] = [];
  private running = 0;
  private readonly maxConcurrency: number;

  constructor(maxConcurrency = Math.max(1, Math.min(4, availableParallelism() - 1))) {
    this.maxConcurrency = maxConcurrency;
  }

  enqueue(
    limit: number,
    metadata: { title?: string; sourceFile?: string } = {},
  ): ReportJob {
    const now = new Date().toISOString();
    const job: ReportJob = {
      id: randomUUID(),
      title: metadata.title?.trim() || `Análise ${this.jobs.size + 1}`,
      sourceFile: metadata.sourceFile?.trim() || "dataset.csv",
      status: "queued",
      progress: 0,
      input: { limit },
      createdAt: now,
      updatedAt: now,
    };

    this.jobs.set(job.id, job);
    this.pending.push(job.id);
    queueMicrotask(() => this.drain());
    return structuredClone(job);
  }

  get(id: string): ReportJob | undefined {
    const job = this.jobs.get(id);
    return job ? structuredClone(job) : undefined;
  }

  list(): ReportJob[] {
    return [...this.jobs.values()]
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .map((job) => structuredClone(job));
  }

  private drain(): void {
    while (this.running < this.maxConcurrency && this.pending.length > 0) {
      const id = this.pending.shift();
      if (id) this.start(id);
    }
  }

  private start(id: string): void {
    const job = this.jobs.get(id);
    if (!job) return;

    this.running += 1;
    this.update(id, { status: "processing", progress: 1 });

    const runningFromTs = import.meta.url.endsWith(".ts");
    const workerUrl = new URL(
      runningFromTs ? "../workers/report.worker.ts" : "../workers/report.worker.js",
      import.meta.url,
    );

    const worker = new Worker(workerUrl, {
      workerData: job.input,
      execArgv: runningFromTs ? ["--import", "tsx"] : [],
    });

    let settled = false;

    worker.on("message", (message: WorkerMessage) => {
      if (message.type === "progress") {
        this.update(id, { progress: Math.min(99, Math.max(1, message.progress)) });
        return;
      }

      settled = true;
      this.update(id, {
        status: "completed",
        progress: 100,
        result: {
          primeCount: message.primeCount,
          durationMs: message.durationMs,
        },
      });
    });

    worker.once("error", (error) => {
      settled = true;
      this.update(id, { status: "failed", error: error.message });
    });

    worker.once("exit", (code) => {
      if (!settled && code !== 0) {
        this.update(id, {
          status: "failed",
          error: `Worker finalizou com código ${code}`,
        });
      }

      this.running -= 1;
      this.drain();
    });
  }

  private update(
    id: string,
    patch: Partial<Pick<ReportJob, "status" | "progress" | "result" | "error">>,
  ): void {
    const current = this.jobs.get(id);
    if (!current) return;

    this.jobs.set(id, {
      ...current,
      ...patch,
      updatedAt: new Date().toISOString(),
    });
  }
}

export const reportJobs = new ReportJobManager();
