/**
 * Simula uma API externa/backend legado.
 * O retorno é `unknown` de propósito: dados externos não são confiáveis
 * só porque nosso TypeScript espera um formato.
 */
export async function fetchCustomerFromUpstream(
  id: string,
  simulateBrokenContract: boolean,
): Promise<unknown> {
  await new Promise((resolve) => setTimeout(resolve, 20));

  if (simulateBrokenContract) {
    // Simula uma alteração de backend: email desapareceu e plan ficou inválido.
    return {
      id,
      name: "Ada Lovelace",
      plan: "premium",
      createdAt: new Date().toISOString(),
    };
  }

  return {
    id,
    name: "Ada Lovelace",
    email: "ada@example.com",
    plan: "pro",
    createdAt: new Date().toISOString(),
  };
}
