const $ = (selector) => document.querySelector(selector);
const state = { jobs: [], timer: null };

function escapeHtml(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function statusLabel(status) {
  return ({ queued: "Pending", processing: "Processing", completed: "Completed", failed: "Failed" })[status] || status;
}

function shortTime(iso) {
  const date = new Date(iso);
  return new Intl.DateTimeFormat("pt-BR", { hour: "2-digit", minute: "2-digit" }).format(date);
}

function clientName(index) {
  return ["Acme S.A.", "Globex Corp.", "Initech", "Umbrella Corp.", "Stark Industries"][index % 5];
}

function renderJobs(jobs) {
  const list = $("#jobsList");
  if (!jobs.length) {
    list.innerHTML = '<div class="empty-state">Nenhum job criado nesta sessão. Clique em “Novo relatório” para enviar um processamento ao Worker Thread.</div>';
    return;
  }

  list.innerHTML = jobs.slice(0, 6).map((job, index) => `
    <div class="job-row">
      <span class="job-id">#${escapeHtml(job.id.slice(0, 8))}</span>
      <div><strong>${escapeHtml(job.title)}</strong><small>${escapeHtml(job.sourceFile)}</small></div>
      <span>${clientName(index)}</span>
      <span class="status ${job.status}">${statusLabel(job.status)}</span>
      <span>${shortTime(job.createdAt)}</span>
      <div class="progress-cell"><div class="progress-bar"><i style="width:${job.progress}%"></i></div><b>${job.progress}%</b></div>
    </div>`).join("");
}

function updateDashboard(payload) {
  const { jobs, summary } = payload;
  state.jobs = jobs;
  const active = summary.processing + summary.queued;

  $("#metricProcessing").textContent = active;
  $("#metricCompleted").textContent = (1248 + summary.completed).toLocaleString("pt-BR");
  $("#queueCount").textContent = active;
  $("#navQueueCount").textContent = active;
  renderJobs(jobs);
}

async function loadJobs() {
  try {
    const response = await fetch("/api/reports", { headers: { accept: "application/json" } });
    if (!response.ok) throw new Error("Falha ao carregar fila");
    updateDashboard(await response.json());
  } catch (error) {
    console.error(error);
  }
}

async function createJob(form) {
  const formData = new FormData(form);
  const body = {
    title: formData.get("title"),
    sourceFile: formData.get("sourceFile"),
    limit: Number(formData.get("limit")),
  };

  const response = await fetch("/api/reports", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });

  const payload = await response.json();
  if (!response.ok) throw new Error(payload?.issues?.[0]?.message || "Não foi possível criar o relatório.");
  return payload;
}

async function simulateContractBreak() {
  const button = $("#simulateContractBtn");
  const result = $("#contractResult");
  button.disabled = true;
  button.textContent = "Validando...";
  try {
    const response = await fetch("/api/customers/customer-123?broken=true");
    const payload = await response.json();
    if (response.status !== 502 || payload.code !== "UPSTREAM_CONTRACT_VIOLATION") {
      throw new Error("A simulação não retornou a quebra esperada.");
    }
    result.classList.add("success");
    result.querySelector(".problem-top strong").innerHTML = '<span>✓</span> Quebra interceptada pelo Zod';
    result.querySelector("p").innerHTML = `A API bloqueou <b>${payload.issues.length}</b> violação(ões) antes de propagar o payload.`;
    result.querySelector("small").textContent = "Resposta 502 UPSTREAM_CONTRACT_VIOLATION — contrato externo protegido em runtime.";
    button.textContent = "Simular novamente →";
  } catch (error) {
    result.classList.remove("success");
    result.querySelector("small").textContent = error.message;
    button.textContent = "Tentar novamente →";
  } finally {
    button.disabled = false;
  }
}

const dialog = $("#reportDialog");
$("#newReportBtn").addEventListener("click", () => dialog.showModal());
$("#closeDialog").addEventListener("click", () => dialog.close());
$("#cancelDialog").addEventListener("click", () => dialog.close());
$("#refreshBtn").addEventListener("click", loadJobs);
$("#simulateContractBtn").addEventListener("click", simulateContractBreak);

$("#reportForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const status = $("#formStatus");
  status.textContent = "Enviando para a fila...";
  try {
    await createJob(form);
    status.textContent = "";
    dialog.close();
    await loadJobs();
  } catch (error) {
    status.textContent = error.message;
  }
});

loadJobs();
state.timer = setInterval(loadJobs, 900);
